﻿// Figure 3.1: Welcome1.cs
// Text-displaying application.

namespace Welcome1
{ 
   class Welcome1
   {
      //Main method begins execution of C# application
      static void Main(string[] args)
      {
         Console.WriteLine("Welcome to C# Programming!");
      }
   }
}