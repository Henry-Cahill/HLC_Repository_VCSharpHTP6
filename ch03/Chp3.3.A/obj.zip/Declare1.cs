﻿// Self Review Assignment 3.3: Declare.cs
// Declare variables c, thisISAVariable, q76354 and number of type int.
using System;

namespace Declare1
{
   class Declare1
   {
      //Main method begins execution of C# application
      static void Main()
      {
         string letter = "c"; //variable that stores the string "c".
         string variable = "thisISAVariable"; //variable that stores the string "thisISAVariable".
         string letternumber = "q76354"; //variable that stores the string "q76354".
         int number = 76354; //variable that stores the integer 76354.
         Console.WriteLine($"Declaring variables {letter}, {variable}, {letternumber} and ({number}) number of type int.");
      }//end Main
   }//end class Declare1
}