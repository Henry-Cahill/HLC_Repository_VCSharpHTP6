﻿// See https://aka.ms/new-console-template for more information
//Figure 3.10: Welcome2.cs
//Displaying one line of text with multiple statements.

using System;

class Welcome2
{
   // Main Method begins execution of C# application.
   static void Main()
   {
      Console.Write("Welcome to");
      Console.WriteLine("C# Programming");
   }//end Main
}//end class Welcome2

