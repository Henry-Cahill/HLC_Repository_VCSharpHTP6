﻿// See https://aka.ms/new-console-template for more information

namespace Prompt11
{
   class Prompt11
   {
      //Main method begins execution of C# application
      static void Main()
      {
         int x = 2;
         int y = 3;

         Console.WriteLine($"x = {x}");
         Console.WriteLine($"Value of {x} + {x} is {x + x}");
         Console.WriteLine("x =");
         Console.WriteLine($"{x + y} = {x + y}");

      }//end Main
   }//end class Prompt11
}