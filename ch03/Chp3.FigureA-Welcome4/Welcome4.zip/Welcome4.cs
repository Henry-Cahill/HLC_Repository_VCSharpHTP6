﻿// See https://aka.ms/new-console-template for more information
//Figure 3.13: Welcome4.cs
//Inserting content into a string with string interpolation.
using System;

class Welcome4
{
   // Main Method begins execution of C# application.
   static void Main()
   {
      string person = "Paul"; //variable that stores the string "Paul"
      Console.WriteLine($"Welcome to C# Programming, {person}!");
   }//end Main
}//end class Welcome4