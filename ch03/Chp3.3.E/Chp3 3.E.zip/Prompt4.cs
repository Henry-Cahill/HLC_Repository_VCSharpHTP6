﻿// See https://aka.ms/new-console-template for more information
// Self Review Assignment 3.3E: Prompt.cs
// Display "This is a C# app" on one line in the console window.
using System;

namespace Prompt4
{
   class Prompt4
   {
      //Main method begins execution of C# application
      static void Main()
      { 
         Console.WriteLine("This is a C# app"); //Display "This is a C# app" on one line in the console window.

      }//end Main
   }//end class Prompt4
}