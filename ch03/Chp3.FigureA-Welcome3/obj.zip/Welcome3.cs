﻿// See https://aka.ms/new-console-template for more information
//Figure 3.11: Welcome3.cs
//Displaying multiple lines with a single statement.
using System;

class Welcome3
{
   // Main Method begins execution of C# application.
   static void Main()
   {
      Console.WriteLine("Welcome\nto\nC#\nProgramming!");
   }//end Main
}//end class Welcome3