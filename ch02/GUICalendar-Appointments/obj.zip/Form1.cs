namespace Calendar_and_Appointments_GUI
{
   public partial class MySchedulerFrm : Form
   {
      public MySchedulerFrm()
      {
         InitializeComponent();
      }
   }
}
