﻿namespace Calculator_GUI
{
   partial class CalculatorFrm1
   {
      /// <summary>
      ///  Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      ///  Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      ///  Required method for Designer support - do not modify
      ///  the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         txb1 = new TextBox();
         Leftpnl1 = new Panel();
         tenbtn11 = new Button();
         zerobtn10 = new Button();
         ninebtn9 = new Button();
         eightbtn8 = new Button();
         sevenbtn7 = new Button();
         sixbtn6 = new Button();
         fivebtn5 = new Button();
         fourbtn4 = new Button();
         threebtn3 = new Button();
         twobtn2 = new Button();
         Onebtn1 = new Button();
         centerpnl2 = new Panel();
         periodbtn13 = new Button();
         equalbtn17 = new Button();
         fowardslashbtn16 = new Button();
         minusbtn14 = new Button();
         starbtn15 = new Button();
         plusbtn12 = new Button();
         rightpnl3 = new Panel();
         CAbtn19 = new Button();
         Cbtn18 = new Button();
         OFF20 = new Button();
         Leftpnl1.SuspendLayout();
         centerpnl2.SuspendLayout();
         rightpnl3.SuspendLayout();
         SuspendLayout();
         // 
         // txb1
         // 
         txb1.Location = new Point(50, 33);
         txb1.Name = "txb1";
         txb1.Size = new Size(843, 55);
         txb1.TabIndex = 0;
         txb1.Text = "0";
         txb1.TextAlign = HorizontalAlignment.Right;
         // 
         // Leftpnl1
         // 
         Leftpnl1.BorderStyle = BorderStyle.Fixed3D;
         Leftpnl1.Controls.Add(tenbtn11);
         Leftpnl1.Controls.Add(zerobtn10);
         Leftpnl1.Controls.Add(ninebtn9);
         Leftpnl1.Controls.Add(eightbtn8);
         Leftpnl1.Controls.Add(sevenbtn7);
         Leftpnl1.Controls.Add(sixbtn6);
         Leftpnl1.Controls.Add(fivebtn5);
         Leftpnl1.Controls.Add(fourbtn4);
         Leftpnl1.Controls.Add(threebtn3);
         Leftpnl1.Controls.Add(twobtn2);
         Leftpnl1.Controls.Add(Onebtn1);
         Leftpnl1.Location = new Point(50, 138);
         Leftpnl1.Name = "Leftpnl1";
         Leftpnl1.Size = new Size(336, 428);
         Leftpnl1.TabIndex = 1;
         // 
         // tenbtn11
         // 
         tenbtn11.Location = new Point(123, 322);
         tenbtn11.Name = "tenbtn11";
         tenbtn11.Size = new Size(190, 93);
         tenbtn11.TabIndex = 10;
         tenbtn11.Text = "00";
         tenbtn11.UseVisualStyleBackColor = true;
         // 
         // zerobtn10
         // 
         zerobtn10.Location = new Point(25, 322);
         zerobtn10.Name = "zerobtn10";
         zerobtn10.Size = new Size(92, 93);
         zerobtn10.TabIndex = 9;
         zerobtn10.Text = "0";
         zerobtn10.UseVisualStyleBackColor = true;
         // 
         // ninebtn9
         // 
         ninebtn9.Location = new Point(221, 223);
         ninebtn9.Name = "ninebtn9";
         ninebtn9.Size = new Size(92, 93);
         ninebtn9.TabIndex = 8;
         ninebtn9.Text = "9";
         ninebtn9.UseVisualStyleBackColor = true;
         // 
         // eightbtn8
         // 
         eightbtn8.Location = new Point(123, 223);
         eightbtn8.Name = "eightbtn8";
         eightbtn8.Size = new Size(92, 93);
         eightbtn8.TabIndex = 7;
         eightbtn8.Text = "8";
         eightbtn8.UseVisualStyleBackColor = true;
         // 
         // sevenbtn7
         // 
         sevenbtn7.Location = new Point(25, 223);
         sevenbtn7.Name = "sevenbtn7";
         sevenbtn7.Size = new Size(92, 93);
         sevenbtn7.TabIndex = 6;
         sevenbtn7.Text = "7";
         sevenbtn7.UseVisualStyleBackColor = true;
         // 
         // sixbtn6
         // 
         sixbtn6.Location = new Point(221, 124);
         sixbtn6.Name = "sixbtn6";
         sixbtn6.Size = new Size(92, 93);
         sixbtn6.TabIndex = 5;
         sixbtn6.Text = "6";
         sixbtn6.UseVisualStyleBackColor = true;
         // 
         // fivebtn5
         // 
         fivebtn5.Location = new Point(123, 124);
         fivebtn5.Name = "fivebtn5";
         fivebtn5.Size = new Size(92, 93);
         fivebtn5.TabIndex = 4;
         fivebtn5.Text = "5";
         fivebtn5.UseVisualStyleBackColor = true;
         // 
         // fourbtn4
         // 
         fourbtn4.Location = new Point(25, 124);
         fourbtn4.Name = "fourbtn4";
         fourbtn4.Size = new Size(92, 93);
         fourbtn4.TabIndex = 3;
         fourbtn4.Text = "4";
         fourbtn4.UseVisualStyleBackColor = true;
         // 
         // threebtn3
         // 
         threebtn3.Location = new Point(221, 25);
         threebtn3.Name = "threebtn3";
         threebtn3.Size = new Size(92, 93);
         threebtn3.TabIndex = 2;
         threebtn3.Text = "3";
         threebtn3.UseVisualStyleBackColor = true;
         // 
         // twobtn2
         // 
         twobtn2.Location = new Point(123, 25);
         twobtn2.Name = "twobtn2";
         twobtn2.Size = new Size(92, 93);
         twobtn2.TabIndex = 1;
         twobtn2.Text = "2";
         twobtn2.UseVisualStyleBackColor = true;
         // 
         // Onebtn1
         // 
         Onebtn1.Location = new Point(25, 25);
         Onebtn1.Name = "Onebtn1";
         Onebtn1.Size = new Size(92, 93);
         Onebtn1.TabIndex = 0;
         Onebtn1.Text = "1";
         Onebtn1.UseVisualStyleBackColor = true;
         // 
         // centerpnl2
         // 
         centerpnl2.BorderStyle = BorderStyle.Fixed3D;
         centerpnl2.Controls.Add(periodbtn13);
         centerpnl2.Controls.Add(equalbtn17);
         centerpnl2.Controls.Add(fowardslashbtn16);
         centerpnl2.Controls.Add(minusbtn14);
         centerpnl2.Controls.Add(starbtn15);
         centerpnl2.Controls.Add(plusbtn12);
         centerpnl2.Location = new Point(414, 138);
         centerpnl2.Name = "centerpnl2";
         centerpnl2.Size = new Size(261, 428);
         centerpnl2.TabIndex = 2;
         // 
         // periodbtn13
         // 
         periodbtn13.Location = new Point(27, 313);
         periodbtn13.Name = "periodbtn13";
         periodbtn13.Size = new Size(92, 93);
         periodbtn13.TabIndex = 13;
         periodbtn13.Text = ".";
         periodbtn13.UseVisualStyleBackColor = true;
         // 
         // equalbtn17
         // 
         equalbtn17.Location = new Point(137, 313);
         equalbtn17.Name = "equalbtn17";
         equalbtn17.Size = new Size(92, 93);
         equalbtn17.TabIndex = 12;
         equalbtn17.Text = "=";
         equalbtn17.UseVisualStyleBackColor = true;
         // 
         // fowardslashbtn16
         // 
         fowardslashbtn16.Location = new Point(137, 214);
         fowardslashbtn16.Name = "fowardslashbtn16";
         fowardslashbtn16.Size = new Size(92, 93);
         fowardslashbtn16.TabIndex = 11;
         fowardslashbtn16.Text = "/";
         fowardslashbtn16.UseVisualStyleBackColor = true;
         // 
         // minusbtn14
         // 
         minusbtn14.Location = new Point(137, 16);
         minusbtn14.Name = "minusbtn14";
         minusbtn14.Size = new Size(92, 93);
         minusbtn14.TabIndex = 10;
         minusbtn14.Text = "-";
         minusbtn14.UseVisualStyleBackColor = true;
         // 
         // starbtn15
         // 
         starbtn15.Location = new Point(137, 115);
         starbtn15.Name = "starbtn15";
         starbtn15.Size = new Size(92, 93);
         starbtn15.TabIndex = 9;
         starbtn15.Text = "*";
         starbtn15.UseVisualStyleBackColor = true;
         // 
         // plusbtn12
         // 
         plusbtn12.Location = new Point(27, 16);
         plusbtn12.Name = "plusbtn12";
         plusbtn12.Size = new Size(89, 291);
         plusbtn12.TabIndex = 0;
         plusbtn12.Text = "+";
         plusbtn12.UseVisualStyleBackColor = true;
         // 
         // rightpnl3
         // 
         rightpnl3.BorderStyle = BorderStyle.Fixed3D;
         rightpnl3.Controls.Add(CAbtn19);
         rightpnl3.Controls.Add(Cbtn18);
         rightpnl3.Location = new Point(743, 138);
         rightpnl3.Name = "rightpnl3";
         rightpnl3.Size = new Size(173, 245);
         rightpnl3.TabIndex = 3;
         // 
         // CAbtn19
         // 
         CAbtn19.Location = new Point(17, 136);
         CAbtn19.Name = "CAbtn19";
         CAbtn19.Size = new Size(133, 81);
         CAbtn19.TabIndex = 1;
         CAbtn19.Text = "C/A";
         CAbtn19.UseVisualStyleBackColor = true;
         // 
         // Cbtn18
         // 
         Cbtn18.Location = new Point(17, 23);
         Cbtn18.Name = "Cbtn18";
         Cbtn18.Size = new Size(133, 81);
         Cbtn18.TabIndex = 0;
         Cbtn18.Text = "C";
         Cbtn18.UseVisualStyleBackColor = true;
         // 
         // OFF20
         // 
         OFF20.Location = new Point(760, 460);
         OFF20.Name = "OFF20";
         OFF20.Size = new Size(133, 81);
         OFF20.TabIndex = 4;
         OFF20.Text = "OFF";
         OFF20.UseVisualStyleBackColor = true;
         // 
         // CalculatorFrm1
         // 
         AutoScaleDimensions = new SizeF(20F, 48F);
         AutoScaleMode = AutoScaleMode.Font;
         ClientSize = new Size(936, 592);
         Controls.Add(OFF20);
         Controls.Add(rightpnl3);
         Controls.Add(centerpnl2);
         Controls.Add(Leftpnl1);
         Controls.Add(txb1);
         Name = "CalculatorFrm1";
         Text = "Calculator";
         Leftpnl1.ResumeLayout(false);
         centerpnl2.ResumeLayout(false);
         rightpnl3.ResumeLayout(false);
         ResumeLayout(false);
         PerformLayout();
      }

      #endregion

      private TextBox txb1;
      private Panel Leftpnl1;
      private Panel centerpnl2;
      private Panel rightpnl3;
      private Button zerobtn10;
      private Button ninebtn9;
      private Button eightbtn8;
      private Button sevenbtn7;
      private Button sixbtn6;
      private Button fivebtn5;
      private Button fourbtn4;
      private Button threebtn3;
      private Button twobtn2;
      private Button Onebtn1;
      private Button tenbtn11;
      private Button plusbtn12;
      private Button fowardslashbtn16;
      private Button minusbtn14;
      private Button starbtn15;
      private Button periodbtn13;
      private Button equalbtn17;
      private Button CAbtn19;
      private Button Cbtn18;
      private Button OFF20;
   }
}
