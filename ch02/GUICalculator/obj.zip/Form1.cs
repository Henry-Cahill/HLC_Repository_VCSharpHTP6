namespace Calculator_GUI
{
   public partial class CalculatorFrm1 : Form
   {
      public CalculatorFrm1()
      {
         InitializeComponent();
      }
   }
}
