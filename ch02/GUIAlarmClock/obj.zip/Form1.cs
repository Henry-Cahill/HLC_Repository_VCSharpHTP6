namespace AlarmClockGUI
{
   public partial class AlarmClockFrm : Form
   {
      public AlarmClockFrm()
      {
         InitializeComponent();
      }
   }
}
